#Team63-AtheneHacks
## Inspiration
Ever since lockdown began in March 2020 and most of us started working and learning from home, our screen time has increased considerably. When we were discussing ideas on a project, we all commented on our increased screen time, headaches, and how our optometrists recommended that we split up our screen time with 20 second breaks every 20 minutes. 

## What it does
This is a cute Google Chrome Extension that reminds the user with a notification to take frequent breaks from screen time. 

## How we built it
We built it with JavaScript and Google Chrome notifications/alerts, over Virtual Studio Code Live Share.

## Challenges we ran into
We originally also wanted to integrate with Google Calendar API so the notifications won't show up during important work meetings, but we realized it is way more difficult than we had originally thought, especially since half of our team is new to coding and most of us really new to JavaScript. We also had difficulties figuring out how to get the timing correct (20 minute timer and 20 seconds break) We also ran into a lot of internet connectivity issues since we are doing this virtually. 

## Accomplishments that we're proud of
We have the notifications working! We are also super proud of the cute icons that we used. 

## What we learned
We learned a lot from this project! The biggest thing we learned is that collaborating as a team is way more fun and we learn a lot from each other- we all have different experiences and skills with coding, and together we were able to create something that we could use on a daily basis. We also agreed to keep working on this project after our hackathon to continue to work on its functionality. 

## What's next for Eyes Cream
Ideally,  we would like to integrate with Google Calendar API, so the notifications won't show up during important work meetings. In addition, we would love to have an options page where the user can customize the timer (colors of notifications, time before needing a break, time of break, etc). 