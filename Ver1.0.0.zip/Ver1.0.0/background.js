//global variables here//
var timer20minsFlag = false;

//Timer//
function timer20mins() {
  chrome.alarms.create("20 minutes timer", { when: Date.now() + (20 * 60 * 1000)});
  return (timer20minsFlag = true);
}
//boolean value true = timer is done, function notification//
//When the user check on the extension, the 20 mins timer will be automatically started//

chrome.browserAction.onClicked.addListener(function (tab) {
  if (timer20minsFlag === false) {
    timer20mins();
  }
});

// returns current time in HH:MM:SS
function currTime() {
  var d = new Date();
  var ampm = d.getHours() >= 12 ? "pm" : "am";
  var hour = d.getHours() % 12;
  if (hour === 0) {
    hour = 12;
  }
  var minute = d.getMinutes();
  var second = d.getSeconds();
  return hour + ":" + minute + ":" + second;
}

//when the alarm is on, the notification will pop up, then it will check which botton does the user pressed
chrome.alarms.onAlarm.addListener(function (alarm) {
  showNotification();
});

//the notification alarm when every 20 mins passes
//inside the alarm notification, there will be three buttom: restart the timer
function showNotification() {
  // Now create the notification
  chrome.notifications.create("reminder", {
    type: "basic",
    iconUrl: "./icons/EyesCream - 128.png",
    title: "Take a break!",
    message: "Look 20 feet away for 20 seconds!",
    contextMessage: currTime(),
    eventTime: Date.now(),
    requireInteraction: true,
    buttons: [
      {
        title: "Done with the break!",
        iconUrl: "./icons/EyesCream - 128.png",
      },
    ],
  });
}

chrome.notifications.onButtonClicked.addListener(function (btnIdx) {
  doneWithBreak();
});

function doneWithBreak() {
  chrome.notifications.clear("20 minutes timer");
  timer20mins();
  console.log("I'm done with my break at " + currTime() + "!");
}
